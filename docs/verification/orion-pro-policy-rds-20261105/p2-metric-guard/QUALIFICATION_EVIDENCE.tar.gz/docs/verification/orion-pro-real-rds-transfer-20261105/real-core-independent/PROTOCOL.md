# Independent real core readback V1

Written before `readback.py`. This is a separate read-only post-commit proof. It does not modify the frozen writer, its acceptance, the source checkpoint, the live source marker, or any database data.

ROOT supplies an already connected, idle, autocommit `statarena_ingest` connection to `run_readback(conn, output_dir)`. This module opens no connection, obtains no credentials, and makes no source, RAM, AWS, SSM, Neon, or HTTP call. ROOT owns the connection lifecycle and bounded child supervision. The module uses one repeatable-read, read-only transaction with UTC, ISO/YMD, extra_float_digits=3, statement_timeout=8000, lock_timeout=1000 and idle_in_transaction_session_timeout=15000. The exact target database, TLS, role, PG version and postmaster epoch must match the V3 pair. It rolls back its read transaction even on failure and never closes the caller's connection.

The offline CLI reads only immutable artifacts, verifies their hashes and continuity, and produces an inspection plan. It is not an executed database acceptance. The precode E2E must first record a real missing-module RED, then exercise this CLI behind network, driver, provider SDK, writer-import and process-launch tripwires. No new local PG fixture is needed: the distinct 9/9 local campaign already qualified the old native oracle and the explicit 106-column substitution contract with unequal generation/snapshot identifiers.

## Expected complete readback

1. Verify pins for the model, old independent SQL-native oracle, 106-component contract, ownership matrix, source native94+67, real receipt contract, both logical/service checkpoints, current descriptor, V3 pair/acceptance/authority, V3 preflight and ordering proof. Verify the current checkpoint differs from the logical one only in the five explicitly allowed routing fields. Preserve the original source transaction clock from the retained V3 preflight metadata.
2. Reconstruct the original source import-run checkpoint from its exact real normalizer contract. Ask PostgreSQL to serialize the entire known typed source import-run row as `ROW(...)::text`. Its length-prefixed native SHA256 must equal the retained source native94 hash before the unframed run SHA is used for any receipt check. Reconstruct the entire original core snapshot the same way, combine it with the retained source B0 native text, and require the exact two-row source snapshot hash. An insufficient preimage is a refusal, never an inferred pass.
3. Read all target runs and snapshots with bounded queries. Require exactly one target run and B0 plus one sealed core snapshot. Derive the generation and snapshot maps independently from these native rows and the source phase. Require positive integer coordinates, injective monotone maps and preservation of bootstrap coordinate 1. Never take a map from the writer report.
4. Check the exact target migration journal hash and values against the independently retained V3 target descriptor; check the full native B0 row unchanged. Check the closed target checkpoint key set, every binding value, its digest, target run parameters/counters, SQL NULL error, source-derived copied count and snapshot key/version/priority/cutoff/manifest. Require `local_only=false`, `full_acceptance=false` and all four target technical clocks equal to its aware checkpoint transaction timestamp. The source clock remains its original 11:16 clock and is not relabelled as a target clock.
5. Run `tests/orion_pro_bulk_local.py:native_rows` over all 91 business relations with independently formed inverse CASE expressions from the frozen 106-column FK-derived contract. Compare row counts and length-prefixed native row SHA256 with source94 exactly. No writer observer, importer export, fixture acceptance, row rewriting, ID remapping or collation override is used. The retained real-domain ordering probe covers 24 text-key relations, 2,823 keys and eight populated relations; it is pinned as a prerequisite.
6. Compute copied rows from the retained source counts of the ownership matrix's copied relations, less the model's exact 12 bootstrap rows. Expected: 553,545 copied rows, 553,562 source rows, 478,547 scalar metric rows. The regenerated three controls are checked separately from the 91 unchanged business tables.

Stop at the first mismatch. Always save setup/input hashes, exact ROOT rerun call, expected and actual outcomes, query text (technical metadata parameters only), comparison hashes, failure traceback, transaction rollback status and connection ownership. Never persist business row payloads. Save a progress receipt after each native relation so a failed/terminated readback remains inspectable. The module has a 300-second monotonic deadline in addition to ROOT's global child bound.

## Failure matrix

| Trigger | Expected observable result |
| --- | --- |
| Missing implementation before code | CLI E2E fails its availability case; other cases remain unverified. |
| Any pin/continuity/order proof drift | Offline refusal before any connection use. |
| Default CLI | Offline-only plan; 0 connections and no database acceptance. |
| Non-idle or non-autocommit supplied connection | Refusal before beginning the read transaction. |
| Wrong database/role/epoch/TLS/version/settings | Refusal before business oracle. |
| Source preimage framing mismatch | Refusal before deriving source_run_sha256. |
| Extra run/snapshot, wrong journal or changed B0 | Refusal; transaction rolled back. |
| Foreign/extra checkpoint key, counters, parameters, NULL kind or clock | Refusal; no native acceptance. |
| Wrong inverse coordinate or any native business difference | First differing relation recorded; later relations unverified. |
| Driver/network/provider/writer attempted by offline CLI | Tripwire raises and CLI E2E fails. |
| Deadline/query error | Failure receipt and rollback; no retry or mutation. |

No target sequence values are read by this proof: ordinary ingest lacks SELECT on sequence values and does not need it for the transport. ROOT may retain a separate admin read-only 67-sequence proof. A passing result proves this frozen committed core only; spatial, remaining detailed families, actor-reference gaps, full leaf fidelity and production activation remain open.

Suggested commit: `test: independently read back the committed real RDS core`
