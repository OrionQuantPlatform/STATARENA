#!/usr/bin/env python3
"""Independent real core oracle. ROOT supplies a connection; default CLI is offline."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time
import traceback

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
CONTROL = {'ingest.dataset_snapshots','ingest.import_runs','ingest.schema_migrations'}
HOST = 'statarena-postgres.clcy2iqyajbl.us-east-2.rds.amazonaws.com'
WRITER_VERSION = 'orion_pro_native_transport_real_v2'
PHASE_VERSION = 'orion_pro_native_transport_real_phase_v2'
ROUTING = ['marker','markerPath','sourceDescriptor','sourceDescriptorSha256','native94Evidence']


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def hashed(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def save(path,value): Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,default=str)+'\n')
def require(ok,message):
    if not ok: raise AssertionError(message)


def framed(rows):
    digest=hashlib.sha256()
    for value in rows:
        body=value.encode();digest.update(str(len(body)).encode()+b':'+body+b'\n')
    return digest.hexdigest()


def inputs():
    pins=json.loads((BASE/'PINS.json').read_text());require(pins['kind']=='independent_real_core_readback_pins_v1','Unknown pin contract')
    loaded={};paths={}
    for key,pin in pins['files'].items():
        path=ROOT/pin['path'];require(sha(path)==pin['sha256'],'Input drift: '+pin['path']);paths[key]=path
        if path.suffix=='.json':loaded[key]=json.loads(path.read_text())
    model=loaded['model'];tables={t['qualified_name']:t for schema in model['schemas'] for t in schema['tables'] if t['phase']!='models'}
    component=loaded['components'];native=loaded['sourceNative'];accepted=loaded['acceptance'];pair=loaded['pair'];contract=loaded['contract'];authority=loaded['authority'];preflight=loaded['preflight'];order=loaded['orderProof']
    require(len(tables)==94 and len(set(tables)-CONTROL)==91,'Expected frozen active94 model')
    require(component['modelSha256']==sha(paths['model']) and component['componentCount']==sum(map(len,component['relations'].values()))==106,'Independent component contract differs')
    require(set(native)=={'tables','sequences'} and len(native['tables'])==94 and len(native['sequences'])==67,'Exact source native94+67 required')
    require(native['tables']==accepted['sourceTables'] and hashed(native['tables'])==accepted['sourceNativeSha256']==contract['sourceNativeSha256'],'Source native94 content differs')
    require(sum(v['rows'] for v in native['tables'].values())==accepted['sourceRows']==contract['sourceRows']==553562,'Source count differs')
    require(accepted['sourceCheckpointSha256']==sha(paths['logicalCheckpoint'])==contract['sourceCheckpointSha256'],'Logical source checkpoint differs')
    require(pair['source']==loaded['currentDescriptor'] and loaded['currentCheckpoint']['sourceDescriptorSha256']==sha(paths['currentDescriptor']),'Current service descriptor differs')
    require(authority['continuity']['routingFields']==ROUTING,'Unexpected continuity exception')
    old=loaded['logicalCheckpoint'];current=loaded['currentCheckpoint']
    require({k:v for k,v in old.items() if k not in ROUTING}=={k:v for k,v in current.items() if k not in ROUTING},'Logical/service content differs')
    require(authority['continuity']['currentServiceCheckpointSha256']==sha(paths['currentCheckpoint']) and authority['continuity']['acceptedLogicalContentSha256']==sha(paths['logicalCheckpoint']),'Continuity checkpoint pins differ')
    require(pair['source']['endpoint']['postmasterStartedAt']==authority['continuity']['actualPostmasterStartedAt'],'Current source epoch differs')
    for name,expected in authority['files'].items():require(sha(ROOT/name)==expected,'V3 authority file drift: '+name)
    require(accepted['pairSha256']==sha(paths['pair']) and pair['writerSha256']==accepted['writerSha256'],'Pair/acceptance binding differs')
    require(preflight['status']=='preflight' and preflight['childExitCode']==0 and preflight['privateAuthenticationRemoved'] is True and preflight['authoritySha256']==sha(paths['authority']),'Retained V3 preflight differs')
    child=preflight['child'];require(child['copyCommands']==child['nextvalCalls']==0 and child['connectionsClosed'] is True,'Preflight was not closed read-only')
    require(order['status']=='pass' and order['relationsInspected']==24 and order['keysCompared']==2823 and len(order['populatedRelationResults'])==8 and all(x[2] is True for x in order['populatedRelationResults']),'Real-domain ordering proof differs')
    require(all(x['fullAcceptance'] is False for x in [pins,accepted,contract,authority]) and authority['productionActivation'] is False,'Scope must remain incomplete core only')
    require(accepted['dataOrigin']=='real_native_sql_checkpoint' and contract['sourcePhases']==accepted['sourcePhases']==current['sourcePhases'] and len(accepted['sourcePhases'])==1,'Real core phase differs')
    seed_rows=sum(map(len,model['seed_data'].values()))+len(model['bootstrap']['relation_contracts']);require(seed_rows==12,'Model bootstrap scope changed')
    copied=sum(native['tables'][n]['rows'] for n in loaded['ownership']['copiedRelations'])-seed_rows;require(copied==553545,'Source-derived copied count differs')
    clock=child['realSourceReceiptAdmission']['sourceTransactionClock'];require(datetime.fromisoformat(clock).tzinfo is not None,'Missing original aware source clock')
    loaded.update(paths=paths,pins=pins,tables=tables,sourceClock=clock,sourceCopiedRows=copied)
    return loaded


def offline_plan():
    data=inputs()
    return {'status':'offline_plan','connections':0,'sourceCalls':0,'businessWrites':[],'realTargetReadbackExecuted':False,
            'businessRelations':91,'separateControlRelations':3,'controlComponents':106,'sourceRows':553562,
            'sourceDerivedCopiedRows':data['sourceCopiedRows'],'bootstrapRowsExcluded':12,
            'sourceMetricRows':data['sourceNative']['tables']['football.player_match_metric_values']['rows'],
            'originalSourceClock':data['sourceClock'],'sourceEpoch':data['pair']['source']['endpoint']['postmasterStartedAt'],
            'logicalCheckpointSha256':sha(data['paths']['logicalCheckpoint']),'currentServiceCheckpointSha256':sha(data['paths']['currentCheckpoint']),
            'pinsSha256':sha(BASE/'PINS.json'),'fullAcceptance':False}


def source_preimages(data):
    """Known typed values only. PostgreSQL's native framing must prove them exact."""
    contract=data['contract'];phase=contract['phase'];binding=contract['binding'];version=binding['transform_version'];clock=data['sourceClock']
    key='real-source-v2:core:'+binding['input_manifest_sha256']
    checkpoint={'kind':binding['kind'],'phase':'core','receipt_key':key,'binding':binding,'generation':phase['generation'],
                'snapshot_id':phase['snapshotId'],'report':contract['report'],'report_sha256':contract['reportSha256']}
    run_values=[phase['runId'],'rebuild','partial',version,binding['transform_sha256'],clock,clock,
                json.dumps(contract['parameters']),json.dumps(contract['counters']),json.dumps(checkpoint),None]
    snapshot_values=[phase['snapshotId'],key,'sealed',contract['sealedManifestSha256'],version,version,clock,clock,None,phase['generation']]
    return run_values,snapshot_values


def run_readback(conn,output_dir,*,root_command=None):
    """Use ROOT's existing ordinary-ingest connection; never connect or mutate data."""
    started=time.monotonic();deadline=started+300;out=Path(output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
    report={'kind':'independent_real_rds_core_readback_v1','status':'running','command':root_command or [sys.executable,*sys.argv],
            'expected':str(BASE/'PROTOCOL.md'),'connectionSuppliedBy':'ROOT','connectionsOpened':0,'sourceCalls':0,'businessWrites':[],
            'rawBodiesPersisted':False,'fullAcceptance':False,'productionActivation':False,'cases':[],'businessCompared':0,'queries':[]}
    begun=False;data=None;failed=None;native_actual={};current='frozen_inputs'
    def tick():require(time.monotonic()<deadline,'Independent readback 300-second deadline exceeded')
    def query(sql,params=()):
        tick();report['queries'].append({'sql':sql,'technicalParameters':list(params)})
        return conn.execute(sql,params).fetchall()
    def passed(name,actual):report['cases'].append({'case':name,'status':'pass','actual':actual});save(out/'progress.json',report)
    try:
        data=inputs();report['inputSha256']={str(p.relative_to(ROOT)):sha(p) for p in [*data['paths'].values(),Path(__file__),BASE/'PINS.json']}
        for path in [*data['paths'].values(),Path(__file__),BASE/'PINS.json']:
            dest=out/'inputs'/path.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
        passed(current,{'pinCount':len(data['paths']),'logicalAndCurrentContentExact':True,'sourceRows':553562})
        current='target_readonly_identity'
        require(conn.autocommit is True and conn.info.transaction_status.name=='IDLE','ROOT connection must be idle and autocommit')
        require(conn.info.host==HOST and conn.info.port==5432,'ROOT connection host/port differs')
        conn.execute('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');begun=True
        for setting in ["SET LOCAL statement_timeout=8000","SET LOCAL lock_timeout=1000","SET LOCAL idle_in_transaction_session_timeout=15000","SET LOCAL timezone='UTC'","SET LOCAL datestyle='ISO,YMD'","SET LOCAL extra_float_digits=3"]:
            tick();report['queries'].append({'sql':setting,'technicalParameters':[]});conn.execute(setting)
        ident=query("SELECT current_database(),current_user,session_user,current_setting('transaction_read_only'),current_setting('transaction_isolation'),current_setting('statement_timeout'),current_setting('lock_timeout'),current_setting('idle_in_transaction_session_timeout'),current_setting('TimeZone'),current_setting('DateStyle'),current_setting('extra_float_digits'),pg_postmaster_start_time(),(SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid()),rolsuper,rolcreaterole,rolcreatedb,rolreplication,rolbypassrls FROM pg_roles WHERE rolname=current_user")
        require(len(ident)==1,'Missing target identity');identity=ident[0];target=data['pair']['target']['endpoint']
        require(identity[:11]==(target['database'],target['actor'],target['actor'],'on','repeatable read','8s','1s','15s','UTC','ISO, YMD','3'),'Actual target identity/settings differ')
        require(identity[11].isoformat()==target['postmasterStartedAt'] and identity[12] is True and all(v is False for v in identity[13:]) and conn.info.server_version==target['serverVersion']==180006,'Actual target epoch/TLS/ordinary-role/PG version differs')
        passed(current,{'database':identity[0],'actor':identity[1],'postmasterStartedAt':identity[11].isoformat(),'tls':True,'readOnly':True,'isolation':'repeatable read','statementTimeout':'8s','lockTimeout':'1s'})
        current='independent_source_preimages'
        run_values,snapshot_values=source_preimages(data)
        source_run=query('SELECT ROW(%s::bigint,%s::text,%s::text,%s::text,%s::text,%s::timestamptz,%s::timestamptz,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb)::text',run_values)[0][0]
        source_snapshot=query('SELECT ROW(%s::bigint,%s::text,%s::text,%s::text,%s::text,%s::text,%s::timestamptz,%s::timestamptz,%s::timestamptz,%s::bigint)::text',snapshot_values)[0][0]
        source_native=data['sourceNative']['tables'];require(source_native['ingest.import_runs']=={'rows':1,'sha256':framed([source_run])},'Exact native source import-run preimage unavailable/different')
        require(source_native['ingest.dataset_snapshots']=={'rows':2,'sha256':framed([data['pair']['source']['bootstrapNativeText'],source_snapshot])},'Exact native source snapshot preimage unavailable/different')
        source_run_sha=hashlib.sha256(source_run.encode()).hexdigest()
        passed(current,{'sourceRunNativeFramedSha256':framed([source_run]),'sourceRunSha256':source_run_sha,'sourceSnapshotsNativeFramedSha256':framed([data['pair']['source']['bootstrapNativeText'],source_snapshot]),'originalSourceClock':data['sourceClock']})
        current='independent_controls3'
        journal=query('SELECT version,content_sha256,applied_at::text,code_commit FROM ingest.schema_migrations ORDER BY version LIMIT 4')
        journal_text=[r[0] for r in query('SELECT ROW(j.*)::text FROM ingest.schema_migrations j ORDER BY version LIMIT 4')]
        require([list(r) for r in journal]==data['pair']['target']['journal'] and framed(journal_text)==data['pair']['target']['journalNativeSha256'],'Target migration journal changed')
        run_rows=query('SELECT id,mode,status,transform_version,code_commit,started_at,finished_at,parameters,counters,checkpoint,error IS NULL FROM ingest.import_runs ORDER BY id LIMIT 2')
        snaps=query('SELECT id,generation,status,manifest_sha256,transform_version,source_priority_version,snapshot_key,knowledge_cutoff_at,created_at,sealed_at,ROW(s.*)::text FROM ingest.dataset_snapshots s ORDER BY id LIMIT 3')
        require(len(run_rows)==1 and len(snaps)==2,'Target must contain exactly one core run and B0 plus sealed core')
        require(snaps[0][0:2]==(1,1) and snaps[0][10]==data['pair']['target']['bootstrapNativeText'],'Target native B0 changed')
        row=run_rows[0];cp=row[9];phase=data['acceptance']['sourcePhases'][0];accepted=data['acceptance'];contract=data['contract'];snap=snaps[1]
        require(isinstance(cp,dict) and all(type(cp.get(k)) is int for k in ['source_generation','source_snapshot_id','source_run_id','generation','snapshot_id','copied_rows']),'Control coordinates/count must be JSON integers')
        require(type(cp.get('transaction_started_at')) is str,'Aware checkpoint clock required');clock=datetime.fromisoformat(cp['transaction_started_at']);require(clock.tzinfo is not None,'Aware checkpoint clock required')
        require(type(snap[0]) is int and type(snap[1]) is int and snap[0]>1 and snap[1]>1 and cp['snapshot_id']==snap[0] and cp['generation']==snap[1],'Destination coordinates differ')
        expected_binding={'kind':PHASE_VERSION,'phase':'core','writer_sha256':accepted['writerSha256'],'model_sha256':sha(data['paths']['model']),
            'bindings_sha256':accepted['bindingsSha256'],'pair_sha256':sha(data['paths']['pair']),'data_origin':'real_native_sql_checkpoint',
            'source_checkpoint_sha256':accepted['sourceCheckpointSha256'],'source_native_sha256':accepted['sourceNativeSha256'],
            'producer_sha256':accepted['producerSha256'],'source_generation':phase['generation'],'source_snapshot_id':phase['snapshotId'],
            'source_run_id':phase['runId'],'source_run_sha256':source_run_sha,'source_phase_manifest_sha256':phase['manifest']}
        require(set(cp)==set(expected_binding)|{'receipt_sha256','generation','snapshot_id','copied_rows','transaction_started_at'} and all(cp[k]==v for k,v in expected_binding.items()),'Closed target checkpoint/binding differs')
        require(cp['copied_rows']==data['sourceCopiedRows'] and cp['receipt_sha256']==hashed({k:v for k,v in cp.items() if k!='receipt_sha256'}),'Source-derived count/checkpoint digest differs')
        require(row[:5]==(phase['runId'],'backfill','partial',WRITER_VERSION,accepted['writerSha256']) and row[10] is True,'Target run identity/status/SQL NULL differs')
        require(row[7]=={'kind':WRITER_VERSION,'pair_sha256':sha(data['paths']['pair']),'data_origin':'real_native_sql_checkpoint','source_run_sha256':source_run_sha,'producer_sha256':accepted['producerSha256']},'Target parameters differ')
        require(row[8]=={'copied_rows':data['sourceCopiedRows'],'full_acceptance':False,'local_only':False} and row[8]['full_acceptance'] is False and row[8]['local_only'] is False and type(row[8]['copied_rows']) is int,'Real target counters/local_only differ')
        require(snap[2:8]==('sealed',hashed(cp),WRITER_VERSION,contract['binding']['transform_version'],'native-real-v2:'+accepted['sourceNativeSha256']+':core',None),'Target snapshot contract differs')
        require(row[5]==row[6]==snap[8]==snap[9]==clock,'Four native target technical clocks differ')
        maps_g={1:1,phase['generation']:snap[1]};maps_s={1:1,phase['snapshotId']:snap[0]}
        require(len(set(maps_g.values()))==len(maps_g)==2 and len(set(maps_s.values()))==len(maps_s)==2 and list(maps_g.values())==sorted(maps_g.values()) and list(maps_s.values())==sorted(maps_s.values()),'Independently observed control maps are not injective/monotone')
        report['generationMap']=maps_g;report['snapshotMap']=maps_s
        save(out/'control3.json',{'journalNativeSha256':framed(journal_text),'targetB0NativeSha256':hashlib.sha256(snaps[0][10].encode()).hexdigest(),'checkpoint':cp,'parameters':row[7],'counters':row[8],'allFourClocks':clock.isoformat(),'sourceDerivedCopiedRows':data['sourceCopiedRows'],'generationMap':maps_g,'snapshotMap':maps_s,'sourceRunSha256':source_run_sha})
        passed(current,{'controlRelations':3,'allFourClocksExact':True,'copiedRows':data['sourceCopiedRows'],'localOnly':False,'generationMap':maps_g,'snapshotMap':maps_s})
        current='independent_native91'
        spec=importlib.util.spec_from_file_location('frozen_independent_sql_native_oracle',data['paths']['oracle']);oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
        substitutions={name:{col:'CASE '+oracle.q(col)+' '+' '.join('WHEN '+str(dst)+' THEN '+str(src) for src,dst in (maps_g if kind=='generation' else maps_s).items())+' ELSE '+oracle.q(col)+' END' for col,kind in cols.items()} for name,cols in data['components']['relations'].items()}
        save(out/'substitutions.json',{'componentContractSha256':sha(data['paths']['components']),'componentCount':106,'generationMap':maps_g,'snapshotMap':maps_s,'substitutions':substitutions})
        for name in sorted(set(data['tables'])-CONTROL):
            tick();columns=data['tables'][name]['columns'];projection=[substitutions.get(name,{}).get(c,oracle.q(c)) for c in columns]
            sql='SELECT ROW('+','.join(projection)+')::text FROM '+oracle.rel(name)+' ORDER BY '+','.join(oracle.q(c) for c in data['tables'][name]['primary_key']['columns'])
            report['queries'].append({'sql':sql,'technicalParameters':[],'oracle':'tests/orion_pro_bulk_local.py:native_rows'})
            native_actual[name]=oracle.native_rows(conn,name,data['tables'],substitutions.get(name));tick()
            require(native_actual[name]==source_native[name],'Independent native mismatch: '+name)
            report['businessCompared']+=1;save(out/'native91-progress.json',native_actual);save(out/'progress.json',report)
        require(report['businessCompared']==91,'Incomplete business oracle')
        save(out/'native91.json',{'source':{n:source_native[n] for n in native_actual},'targetInverse':native_actual,'allExact':True,'sourceNativeSha256':accepted['sourceNativeSha256']})
        passed(current,{'businessRelations':91,'allCountsAndNativeHashesExact':True,'sourceScalarRows':source_native['football.player_match_metric_values']['rows'],'bootstrapRowsPreserved':12})
        report['status']='pass_committed_core_only'
    except BaseException as error:
        failed=error;report.update(status='fail',errorType=type(error).__name__,error=str(error),traceback=traceback.format_exc())
        report['cases'].append({'case':current,'status':'fail','error':str(error)})
    finally:
        if begun:
            try:conn.rollback();report['readTransactionRolledBack']=True
            except BaseException as error:
                report['readTransactionRolledBack']=False;report['rollbackErrorType']=type(error).__name__;failed=failed or error;report['status']='fail'
        else:report['readTransactionRolledBack']=None
        report['callerConnectionClosed']=conn.closed;report['callerRetainsConnection']=True;report['elapsedSeconds']=round(time.monotonic()-started,3)
        if data is not None:
            try:report['inputsUnchanged']=all(sha(ROOT/p)==h for p,h in report['inputSha256'].items())
            except OSError:report['inputsUnchanged']=False
            if not report['inputsUnchanged']:
                failed=failed or AssertionError('Independent readback inputs changed during execution')
                report['status']='fail';report['inputDriftRefused']=True
        save(out/'result.json',report)
    if failed:raise AssertionError('Independent readback refused; inspect '+str(out/'result.json')) from failed
    return report


if __name__=='__main__':
    require(len(sys.argv)==1,'Only offline default CLI is available; ROOT supplies a live connection through run_readback')
    print(json.dumps(offline_plan(),sort_keys=True))
