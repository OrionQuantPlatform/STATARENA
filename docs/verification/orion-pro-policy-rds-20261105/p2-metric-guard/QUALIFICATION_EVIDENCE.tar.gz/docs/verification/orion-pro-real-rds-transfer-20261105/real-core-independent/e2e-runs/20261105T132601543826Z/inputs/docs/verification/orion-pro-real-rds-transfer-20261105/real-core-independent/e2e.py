#!/usr/bin/env python3
"""Precode CLI E2E for the independent real-core readback; no database access."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import traceback

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
TARGET = BASE/'readback.py'
CASES = ['implementation_available', 'offline_plan', 'offline_connection_tripwires', 'root_connection_interface']


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v): Path(p).write_text(json.dumps(v,indent=2,default=str)+'\n')


def main():
    sys.path.insert(0,str(ROOT/'tests'))
    from orion_e2e_process import run_bounded
    run=BASE/'e2e-runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');(run/'inputs').mkdir(parents=True)
    report={'kind':'independent_real_core_readback_cli_e2e_v1','command':[sys.executable,str(Path(__file__))],
            'expected':str(BASE/'PROTOCOL.md'),'cases':[],'connections':0,'sourceCalls':0,'businessWrites':[],
            'fullAcceptance':False,'realTargetReadbackExecuted':False,'inputs':{}}
    for p in [Path(__file__),BASE/'PROTOCOL.md',BASE/'PINS.json',TARGET,ROOT/'tests/orion_e2e_process.py']:
        if p.is_file():
            dest=run/'inputs'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);report['inputs'][str(p.relative_to(ROOT))]=sha(p)
    started=time.monotonic();block=None;private=None
    env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','USER','TMPDIR','LANG']};env['PYTHONDONTWRITEBYTECODE']='1'
    def invoke(argv,label,tripwire=False):
        childenv=dict(env)
        if tripwire:childenv['PYTHONPATH']=str(private)
        result=run_bounded(argv,cwd=ROOT,env=childenv,deadline=started+45,term_seconds=1,drain_seconds=1,output_limit=1024**2)
        (run/(label+'.stdout.log')).write_text(result.stdout);(run/(label+'.stderr.log')).write_text(result.stderr)
        assert result.returncode==0,(result.returncode,result.stderr[-1000:])
        return json.loads(result.stdout)
    try:
        for name in CASES:
            if block:report['cases'].append({'case':name,'status':'unverified','reason':block});continue
            try:
                if name=='implementation_available':
                    assert TARGET.is_file(),'Independent readback implementation is absent (expected precode RED)'
                    actual={'sha256':sha(TARGET)}
                elif name=='offline_plan':
                    p=invoke([sys.executable,str(TARGET)],name)
                    assert p['status']=='offline_plan' and p['connections']==0 and p['realTargetReadbackExecuted'] is False
                    assert p['businessRelations']==91 and p['controlComponents']==106 and p['sourceDerivedCopiedRows']==553545 and p['sourceRows']==553562
                    actual=p
                elif name=='offline_connection_tripwires':
                    private=Path(tempfile.mkdtemp(prefix='orion-independent-tripwire-',dir='/tmp'))
                    (private/'sitecustomize.py').write_text("import builtins, socket, subprocess\n_original=builtins.__import__\ndef guarded(name,*args,**kwargs):\n if name.split('.')[0] in {'psycopg','psycopg2','boto3','botocore','requests','urllib3'} or 'orion_pro_native_transport' in name:\n  raise RuntimeError('Forbidden readback offline import: '+name)\n return _original(name,*args,**kwargs)\nbuiltins.__import__=guarded\ndef deny(*a,**k):raise RuntimeError('Forbidden readback offline connection/process')\nsocket.socket.connect=deny\nsocket.socket.connect_ex=deny\nsocket.create_connection=deny\nsubprocess.Popen=deny\n")
                    p=invoke([sys.executable,str(TARGET)],name,True);assert p['status']=='offline_plan' and p['connections']==0
                    actual={'connections':0,'tripwires':['driver','socket','provider_sdk','writer_import','child_process']}
                elif name=='root_connection_interface':
                    code="import importlib.util,json;from pathlib import Path;p=Path("+repr(str(TARGET))+");s=importlib.util.spec_from_file_location('independent_root_readback',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(json.dumps({'callable':callable(m.run_readback),'opensConnections':hasattr(m,'connect')}))"
                    p=invoke([sys.executable,'-c',code],name,True);assert p=={'callable':True,'opensConnections':False};actual=p
                report['cases'].append({'case':name,'status':'pass','actual':actual})
            except BaseException as error:
                block=name+': '+str(error);report['cases'].append({'case':name,'status':'fail','error':str(error),'traceback':traceback.format_exc()})
    finally:
        if private is not None:shutil.rmtree(private)
        report['elapsedSeconds']=round(time.monotonic()-started,3);report['status']='fail' if block else 'offline_only_pass'
        report['counts']={k:sum(x['status']==k for x in report['cases']) for k in ['pass','fail','unverified']}
        report['cleanup']={'ownedTripwireDirectoryRemoved':private is None or not private.exists(),'pgStarted':False}
        save(run/'result.json',report);print(json.dumps({'status':report['status'],'counts':report['counts'],'evidence':str(run/'result.json')}))
    return 1 if block else 0


if __name__=='__main__':raise SystemExit(main())
